// const oldFetch = window.fetch;
// window.fetch = function(url, options) {
//   if (url === )
// }